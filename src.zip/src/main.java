import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Scanner;

public class main {
    public static void main(String[] args) throws URISyntaxException, IOException {
        Utils utils = new Utils();

        Ex0 ex0 = new Ex0();
        ex0.prueba();

        utils.separador();

        Ex1 ex1 = new Ex1();
        ex1.prueba();

        utils.separador();


        Ex2 ex2 = new Ex2();
        ex2.prueba();

        utils.separador();

        Ex3 ex3 = new Ex3();
        System.out.println("introduce una ruta de archivo");
        String ruta = utils.scanner.nextLine();
        ex3.prueba(ruta);

        utils.separador();

        Ex4 ex4 = new Ex4();
        ex4.prueba();
    }
}
